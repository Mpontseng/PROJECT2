# tax_app/forms.py
from django import forms

class AuditForm(forms.Form):
    taxpayer_name = forms.CharField(max_length=100, label='Taxpayer Name')
    audit_type = forms.CharField(max_length=100, label='Audit Type')
    audit_status = forms.ChoiceField(
        choices=[('ongoing', 'Ongoing'), ('completed', 'Completed')],
        label='Audit Status'
    )
    findings = forms.CharField(widget=forms.Textarea, label='Findings')
    enforcement_actions = forms.CharField(widget=forms.Textarea, label='Enforcement Actions')
